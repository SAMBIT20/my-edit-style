// Make a 1080x1920 cover in the reel's whiteboard style.
// usage: node cover.js cover.json out.png
//   cover.json: {"kicker": "Interview question", "kicker_icon": "mic", "title": "SQL or\n*NoSQL*?",
//                "left": {"icon": "table-2", "label": "SQL"}, "right": {"icon": "braces", "label": "NoSQL"},
//                "sub": "What should you *answer*?", "photo": "/abs/path/frame.png"}
const fs = require('fs'), path = require('path'), puppeteer = require('puppeteer-core');
const K = path.resolve(__dirname, '..'), [, , specPath, out] = process.argv;
const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));
const ICONS = {};
for (const n of [spec.kicker_icon, spec.left?.icon, spec.right?.icon].filter(Boolean)) {
  const f = path.join(K, 'node_modules/lucide-static/icons', n + '.svg');
  if (fs.existsSync(f)) ICONS[n] = fs.readFileSync(f, 'utf8').replace(/<!--.*?-->/s, '').replace(/width="24"\s+height="24"/, 'width="100%" height="100%"');
  else console.warn('unknown icon:', n);
}
spec.photo = 'file://' + path.resolve(spec.photo);
(async () => {
  const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true, args: ['--allow-file-access-from-files', '--force-color-profile=srgb'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1080, height: 1920 });
  await page.goto('file://' + path.join(K, 'engine/cover.html'));
  await page.evaluate(async (ICONS, spec) => { window.ICONS = ICONS; await Promise.all(['600 10px Pop', '700 10px Pop'].map(f => document.fonts.load(f))); await window.render(spec); }, ICONS, spec);
  await page.screenshot({ path: out });
  await browser.close(); console.log(out);
})();
