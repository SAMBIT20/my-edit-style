#!/usr/bin/env bash
# One-time setup. Prints READY, or what is missing.
K="$(cd "$(dirname "$0")/.." && pwd)"; E="$HOME/.claude/skills/my-edit-style"
command -v ffmpeg >/dev/null || { echo NEED_FFMPEG; exit 1; }
command -v node >/dev/null || { echo NEED_NODE; exit 1; }
[ -x "${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}" ] || { echo NEED_CHROME; exit 1; }
[ -d "$E" ] || { echo NEED_MY_EDIT_STYLE; exit 1; }
[ -x "$E/.venv/bin/python" ] || bash "$E/scripts/setup.sh" >/dev/null || { echo NEED_MY_EDIT_STYLE_SETUP; exit 1; }
[ -d "$K/node_modules/puppeteer-core" ] || (cd "$K" && npm install --silent) || { echo NEED_NPM_INSTALL; exit 1; }
echo READY
