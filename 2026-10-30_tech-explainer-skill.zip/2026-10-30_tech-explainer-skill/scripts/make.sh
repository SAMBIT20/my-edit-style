#!/usr/bin/env bash
# Build the explainer: whiteboard animated panel on top, graded presenter below, voice at -14 LUFS.
# usage: make.sh scenes.json input.mov out.mp4 [panel_h=1000] [head_at=0.42] [zoom=1.0]
set -e
K="$(cd "$(dirname "$0")/.." && pwd)"; E="$HOME/.claude/skills/my-edit-style"
SPEC="$1"; SRC="$2"; DST="$3"; PH="${4:-1000}"; HEAD="${5:-0.42}"; ZOOM="${6:-1.0}"
W=1080; H=1920; VH=$((H - PH)); T="$(mktemp -d)"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$SRC")

echo "1/4 preparing footage"   # cut any black bars, 1080 wide, first audio track only (iPhones add a spatial one)
BARS=$(ffmpeg -ss $(echo "$DUR/3" | bc) -i "$SRC" -t 3 -vf cropdetect=limit=24:round=2 -f null - 2>&1 | grep -o "crop=[0-9:]*" | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
ffmpeg -v error -y -i "$SRC" -map 0:v:0 -map 0:a:0 -vf "${BARS:-null},scale=$W:-2,fps=30" -c:v libx264 -crf 16 -preset fast -c:a aac -b:a 192k "$T/src.mp4"

echo "2/4 colour grade + loudness (my-edit-style look)"
echo '{"effects":[{"fx":"film-grade","start":0,"end":99999}]}' > "$T/grade.json"
bash "$E/scripts/render.sh" "$T/grade.json" "$T/src.mp4" "$T/graded.mp4" >/dev/null

echo "3/4 animating the visual panel"
node "$K/scripts/panel.js" "$SPEC" "$T/panel.mp4" --dur "$DUR" --w $W --h $PH

echo "4/4 putting it together"
CROP=$("$E/.venv/bin/python" "$K/scripts/framing.py" "$T/graded.mp4" $W $VH "$HEAD" "$ZOOM")
# clean hard edge between whiteboard and video, as in main.mp4
ffmpeg -v error -y -i "$T/panel.mp4" -i "$T/graded.mp4" -filter_complex "\
[1:v]crop=$CROP,scale=$W:$VH,setsar=1[cam];\
[0:v]setsar=1[top];[top][cam]vstack=2,format=yuv420p[v]" \
 -map "[v]" -map 1:a -c:v libx264 -crf 17 -preset medium -c:a copy -shortest -movflags +faststart "$DST"
rm -rf "$T"; echo "Done: $DST"
