#!/usr/bin/env python3
"""Pick a steady crop for the presenter strip so the face sits nicely in it.
usage: framing.py video.mp4 strip_w strip_h [head_at=0.42] [zoom=1.0]  -> prints "w:h:x:y" for ffmpeg crop"""
import os, subprocess, sys
import cv2, numpy as np

src, SW, SH = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
head_at = float(sys.argv[4]) if len(sys.argv) > 4 else 0.42
zoom = float(sys.argv[5]) if len(sys.argv) > 5 else 1.0
model = os.path.expanduser('~/.claude/skills/my-edit-style/models/yunet.onnx')
dur = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', src], capture_output=True, text=True).stdout)
cap = cv2.VideoCapture(src); W, H = int(cap.get(3)), int(cap.get(4))
fd = cv2.FaceDetectorYN.create(model, '', (W, H), 0.6, 0.3, 20)
xs, ys = [], []
for i in range(12):  # sample the whole clip; a median ignores the odd glance away
    cap.set(cv2.CAP_PROP_POS_MSEC, (i + 0.5) / 12 * dur * 1000); ok, img = cap.read()
    if not ok: continue
    _, f = fd.detect(img)
    if f is not None and len(f): x, y, w, h = max(f, key=lambda r: r[2] * r[3])[:4]; xs.append(x + w / 2); ys.append(y + h / 2)
cx, cy = (np.median(xs), np.median(ys)) if xs else (W / 2, H * 0.4)
# largest crop of the strip's shape that fits, shrunk by zoom
cw = min(W, H * SW / SH) / zoom; ch = cw * SH / SW
x = int(np.clip(cx - cw / 2, 0, W - cw)); y = int(np.clip(cy - ch * head_at, 0, H - ch))
print(f'{int(cw) // 2 * 2}:{int(ch) // 2 * 2}:{x}:{y}')
