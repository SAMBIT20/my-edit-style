// Render the animated visual panel.
// usage: node panel.js scenes.json out.mp4 --dur 38.9 [--w 1080 --h 1000 --fps 30]
//        node panel.js scenes.json out.png --still 5,12.5      (check PNGs: out_5.png, out_12.5.png)
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const puppeteer = require('puppeteer-core');
const K = path.resolve(__dirname, '..');
const [, , specPath, out, ...rest] = process.argv;
const opt = {}; for (let i = 0; i < rest.length; i += 2) opt[rest[i].replace(/^--/, '')] = rest[i + 1];
const W = +(opt.w || 1080), H = +(opt.h || 1000), FPS = +(opt.fps || 30);
const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));

// inline only the Lucide icons this plan uses
const ICONS = {}, names = new Set(['check', 'x', 'terminal']);
JSON.stringify(spec).replace(/"(?:icon|tag_icon|label_icon)"\s*:\s*"([\w-]+)"/g, (_, n) => names.add(n));
for (const n of names) {
  const f = path.join(K, 'node_modules/lucide-static/icons', n + '.svg');
  if (fs.existsSync(f)) ICONS[n] = fs.readFileSync(f, 'utf8').replace(/<!--.*?-->/s, '').replace(/width="24"\s+height="24"/, '');
  else console.warn('unknown icon:', n, '(see https://lucide.dev/icons)');
}
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

(async () => {
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: true, args: ['--allow-file-access-from-files', '--force-color-profile=srgb'] });
  const page = await browser.newPage();
  await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
  await page.goto('file://' + path.join(K, 'engine/stage.html') + `?w=${W}&h=${H}`);
  await page.evaluate(async (ICONS, spec) => {
    window.ICONS = ICONS;
    await Promise.all(['500 10px Pop', '600 10px Pop', '700 10px Pop', '400 10px Mono', '500 10px Mono'].map(f => document.fonts.load(f)));
    window.load(spec);
  }, ICONS, spec);

  if (opt.still) {
    for (const t of opt.still.split(',')) {
      await page.evaluate(t => window.seek(t), +t);
      const f = out.replace(/\.png$/, `_${t}.png`); await page.screenshot({ path: f }); console.log(f);
    }
    return browser.close();
  }
  const dur = +(opt.dur || spec.duration), n = Math.ceil(dur * FPS);
  const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', FPS, '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '14', '-pix_fmt', 'yuv420p', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  for (let i = 0; i < n; i++) {
    await page.evaluate(t => window.seek(t), i / FPS);
    const buf = await page.screenshot({ type: 'png', optimizeForSpeed: true });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (i % 150 === 0) process.stdout.write(`\r  panel ${Math.round(100 * i / n)}%`);
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r)); await browser.close();
  console.log(`\r  panel done: ${out}`);
})();
