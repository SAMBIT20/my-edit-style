---
name: tech-explainer
description: Turns Sambit's talking-head recording about any technology (databases, APIs, AI, system design…) into a split-screen explainer reel. The top half is a white grid-paper "whiteboard" (yellow title tags, pastel boxes with dark outlines, blue icon discs, chips, typing code, tables, arrow diagrams, pop-in animation) timed to his words; the bottom half is him with his approved warm grade and loud voice. Use when he sends a tech video to edit, asks for "visuals", "explainer", "like the SQL video", or types /tech-explainer.
---

# Tech explainer

The user is not technical. Keep replies short, do the work yourself, never ask them to run commands.
`K` = this skill's folder. Grade, transcription and face model are borrowed from the sibling skill `~/.claude/skills/my-edit-style` (must exist; run its `scripts/setup.sh` once if its `.venv` is missing). First run: `bash K/scripts/setup.sh` → `READY` (installs puppeteer-core, Lucide icons, fonts). `NEED_FFMPEG`: `brew install ffmpeg`. `NEED_NODE`: `brew install node`. `NEED_CHROME`: install Google Chrome. `NEED_MY_EDIT_STYLE`: that sibling skill must be installed first.

Outputs go in `~/Documents/My-Edits/` (the same folder as `my-edits`; macOS ignores case) named `YYYY-MM-DD_<topic-slug>` (3–5 words about what the video *says*; add `-v2` rather than overwrite), with `_words.json` and `_scenes.json` beside the `.mp4`.

## The look (copied from main.mp4, the "AI inference stack" reel; keep it consistent)
- **Layout**: 1080×1920. Animated panel on top (1000 px), presenter below (920 px, face-centred crop), clean hard edge between them. No captions over the face: the panel headline *is* the caption.
- **Notch-safe top:** the headline starts 170 px from the top (`.scene` padding in `engine/stage.html`). The user saw it hidden under the iPhone notch/status bar at 75 px, so never move anything above ~160 px.
- **Panel style: light mode only.** **The user rejected a dark/black background outright ("I don't like this black background at all"), so never go back to dark.** White grid paper. Headline = yellow title tag (Poppins bold, dark 3 px outline, `*key*` word in orange). Below it, 1–3 components: pastel cards (green/yellow/blue/purple, rotating automatically, or set `color`) with a dark outline, an icon tile and a bold title, white rows inside; light-blue chips (pink `bad`, green `ok`, yellow `accent`); solid blue icon discs (`orb`); thin dark arrows. Everything fades and pops into place on the spoken word; scenes fade out as the next starts.
- Presenter: the `my-edit-style` film grade (warm, face bright) and voice loudness-normalised to -14 LUFS.

## Steps
1. **Transcribe**: `~/.claude/skills/my-edit-style/.venv/bin/python ~/.claude/skills/my-edit-style/scripts/transcribe.py <video> ~/Documents/my-edits/<name>_words.json`. Read it all; note what is misheard.
2. **Storyboard** `~/Documents/my-edits/<name>_scenes.json` (see `presets/example-scenes.json`: the approved white SQL-vs-NoSQL reel, 2026-10-30, 93 s, 15 scenes). This is the craft; do it by hand:
   - One scene per idea, **at least ~3.5 s, ideally 5–8 s**. `start` = the time the idea's first word is spoken (scenes end when the next one starts).
   - **Readable pace (the user asked for this):** viewers must have time to read. Merge short ideas instead of flashing them. Every item should arrive ≥ 1.5 s before its scene ends (speed up typing `cps` if needed), and nothing new should appear in the last second of a scene.
   - `headline`: a **short rewrite** (2–6 words) of what he says, not a transcript. Exactly one `*key*` per headline. Questions stay questions. Optional `sub`: tiny mono line (`begin · commit · rollback`).
   - Items appear **on the word that names them**: set each `at` to that word's start time from words.json (minus ~0.1 s). This sync is what makes it feel edited, so never leave everything at the default stagger.
   - Visualise the *mechanism*, not clip-art: the real table, the real query, the real request flow, the real numbers. Invent tiny realistic sample data (names like asha/ravi/meera, ₹ amounts).
   - Max ~3 components per scene; the panel shrinks content that doesn't fit, but crowded scenes look cheap.
3. **Check stills**: `node K/scripts/panel.js <scenes> /tmp/chk.png --still 3,9,15,...` (one time in the *middle* of each scene, not near its end, because scenes fade out at the end). Look at every PNG: nothing overlapping, text readable, items present while being talked about.
4. **Render**: `bash K/scripts/make.sh <scenes> <video> ~/Documents/my-edits/<name>.mp4` (≈5 s of work per 1 s of video). Optional extra args: `panel_h head_at zoom` (defaults `1000 0.42 1.0`; zoom 1.2 for a tighter face).
**Quick test** (the user likes to check before a full render): `ffmpeg -i <video> -t 10 -map 0:v:0 -map 0:a:0 -c copy /tmp/src10.mov`, then run `make.sh` on that file → `<name>_10s-test.mp4` (about 1 min).
Footage with black bars (letterboxed uploads) is handled: `make.sh` detects and cuts the bars before framing.
5. Spot-check a few frames of the final mp4, then `open -a "QuickTime Player" <out>` (VS Code previews play muted) and tell him where it is.
6. **Cover + caption** (he asks for these after each video; offer them):
   - Photo: pull ~12 frames of the presenter strip from the final mp4 (`-vf crop=1080:920:0:1000`) and pick one with eyes to camera and mouth closed or a slight smile → `<name>_cover-photo.png`.
   - Write `<name>_cover.json` (`kicker`, `kicker_icon`, `title` with `\n` and one `*key*`, optional `left`/`right` `{icon,label}` for an X-vs-Y topic, `sub`, `photo`) and run `node K/scripts/cover.js <json> ~/Documents/My-Edits/<name>_cover.png`. Title ≤ 3–4 words, big. Check it at full size *and* the Instagram grid crop (`crop=1080:1440:0:240`): the title and face must show in the crop, and nothing may touch the photo edge.
   - `<name>_caption.txt`: YouTube Shorts title (hook, ≤ 60 chars), a description that summarises the video's points as short ✅/❌ bullets and ends with a save/share call to action, **exactly 5 Instagram hashtags** (Instagram's limit, as the user pointed out: 2 topic tags, 1 field tag, 2 audience tags, e.g. `#sql #nosql #systemdesign #codinginterview #placementpreparation`), and comma-separated YouTube tags. Base everything only on what he actually says.

## Components (`type`; every item takes `at` = seconds into the video)
| type | fields | use for |
|---|---|---|
| `orb` | `icon`, `size` (200), `label`, `label_icon`, `dim` | the "concept" hero: blue disc with a white icon |
| `chip` | `icon`, `text` (`*bold*` ok), `tone`: `ok`/`bad`/`accent` | names, tags, verdicts |
| `kv` | `title`, `icon`, `width`, `color`, `rows:[{k, icon, v, at, type:true, tone:"accent"}]` | config/stack/"form" cards; `type` types the value |
| `table` | `title`, `icon`, `cols`, `rows`, `rows_at`, `stagger`, `badges` | DB rows, comparisons |
| `code` | `title`, `icon`, `lines`, `type_at`, `cps` | queries, commands, snippets (types itself; UPPERCASE words bold, `//`/`--` comments dim) |
| `checklist` | `title`, `items:[{icon, text, at, check_at, bad}]` | criteria, pros/cons (`check_at: 99` = never ticked) |
| `radio` | `title`, `options`, `select`, `select_at`, `reason`, `reason_at` | "which would you pick?" moments |
| `graph` | `w`, `h`, `nodes:[{id, text, icon, x, y, at, orb}]`, `edges:[[from, to, at]]` | architecture, relations, request flow (x/y are 0–1) |
| `stat` | `label`, `icon`, `value`, `to`, `change_at` | numbers that change (balances, latency) |
| `big` | `text` or `from`/`to`/`suffix`/`dur`, `sub` | one huge number/year |
| `tiles` | `letters:[{t, s}]`, `focus`, `focus_at` | acronyms (MERN, ACID, CRUD) |
| `bar` | `title`, `from`, `to`, `warn`, `fill_at` | load, usage, limits |
| `toggle` | `label`, `icon`, `on_at` | feature flags/"turn on sharding" |
| `row` | `items`, `gap` | put components side by side |
| `link` | `w` | dotted connector between items in a row |
Icons: any Lucide name (lucide.dev/icons), e.g. `database`, `server`, `cpu`, `cloud`, `globe`, `lock`, `key-round`, `zap`, `git-branch`, `container`, `brain-circuit`, `message-square`. An unknown name prints a warning and renders blank, so fix it.

Built on: Poppins and JetBrains Mono (OFL, `engine/fonts`), Lucide icons (ISC), puppeteer-core, and the `my-edit-style` grade.
