#!/usr/bin/env bash
# Render the look, then bring the voice up to social-media loudness (-14 LUFS, stereo).
# usage: render.sh plan.json in.mp4 out.mp4          (pass --still 4.5,12 as a 4th arg for check PNGs instead: out must end in .png)
set -e
K="$(cd "$(dirname "$0")/.." && pwd)"; PLAN="$1"; SRC="$2"; DST="$3"; shift 3
if [ "$1" = "--still" ]; then exec "$K/.venv/bin/python" "$K/scripts/captions.py" --plan "$PLAN" "$SRC" "$DST" --still "$2"; fi
TMP="$(mktemp -d)/raw.mp4"
"$K/.venv/bin/python" "$K/scripts/captions.py" --plan "$PLAN" "$SRC" "$TMP"
ffmpeg -v error -y -i "$TMP" -map 0:v -map 0:a -c:v copy -af "loudnorm=I=-14:TP=-1.5:LRA=11" -ac 2 -ar 48000 -c:a aac -b:a 192k -movflags +faststart "$DST"
rm -f "$TMP"; echo "Done: $DST"
