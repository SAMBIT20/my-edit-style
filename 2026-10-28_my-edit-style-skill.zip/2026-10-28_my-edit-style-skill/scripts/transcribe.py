#!/usr/bin/env python3
"""Find when each word is said.  usage: python transcribe.py video.mp4 [out.words.json]   (prints "12.34  word" lines)"""
import json, os, subprocess, sys
import numpy as np
from faster_whisper import WhisperModel

src = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(src)[0] + '.words.json'
# decode with ffmpeg ourselves: newer PyAV breaks faster-whisper's own decoder
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', src, '-f', 'f32le', '-ac', '1', '-ar', '16000', '-'], capture_output=True, check=True).stdout
model = WhisperModel(os.environ.get('WHISPER_MODEL', 'small'), device='cpu', compute_type='int8')
segs, _ = model.transcribe(np.frombuffer(raw, np.float32), word_timestamps=True, vad_filter=True)
words = [{'w': w.word.strip(), 's': round(w.start, 2), 'e': round(w.end, 2)} for s in segs for w in (s.words or [])]
json.dump(words, open(out, 'w'), indent=0)
for w in words: print(f"{w['s']:7.2f}  {w['w']}")
print(f'\nSaved {len(words)} words to {out}')
