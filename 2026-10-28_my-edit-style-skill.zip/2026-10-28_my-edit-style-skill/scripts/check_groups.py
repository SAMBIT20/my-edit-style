#!/usr/bin/env python3
"""Show how a plan's caption groups line up with the spoken words.  usage: python check_groups.py plan.json"""
import json, sys
import captions
c = next(f for f in json.load(open(sys.argv[1]))['effects'] if f['fx'] == 'captions')
fixes = {k.lower(): v for k, v in (kv.split('=', 1) for kv in c.get('fix', '').split('|') if '=' in kv)}
words = json.load(open(c['words']))
ps = captions.phrases(words, fixes, [g for g in c['groups'].split('|') if g.strip()])
for p in ps:
    print(f"{p[0]['s']:6.2f}  {p[0]['until'] - p[0]['s']:4.1f}s  " + ' '.join(f"*{w['t']}*" if w['emph'] else w['t'] for w in p) + (' ♥' if p[-1].get('heart') else ''))
n = sum(len(p) for p in ps)
print(f"\n{n} of {len([w for w in words if any(ch.isalnum() for ch in w['w'])])} spoken words placed" + ('' if ps and ps[-1][-1]['s'] == words[-1]['s'] else '  <-- MISMATCH: groups do not end on the last spoken word'))
