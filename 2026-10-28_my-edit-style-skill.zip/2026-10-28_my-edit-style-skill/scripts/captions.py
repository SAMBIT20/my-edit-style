#!/usr/bin/env python3
"""Film grade + editorial captions beside you: a tight cream sans line, key words in a big gold italic serif, words fading in as you say them.

usage: python captions.py --plan plan.json in.mp4 out.mp4      (same flags as fx.py, adds two effects)
  {"fx": "film-grade"}                                        warm and bright on you, deeper shadows, the room a touch darker
  {"fx": "captions", "words": "in.words.json"}                options: groups, fix, color, accent, size
    groups: phrases with |, in spoken order. Wrap key words in *stars* for the gold italic, end with ♥ for a little heart.
            e.g. "I would see *couples online*|being *loved* ♥"
    fix:    spelling fixes, "sas=SaaS|..."
"""
import json, re
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFilter
import fx
from fx import effect, clamp, font, rgb, comp, vignette, cached, heart

fx.FONT['inter'] = fx.FONT['ui']; fx.WGHT['inter'] = (32, 520)
CREAM, GOLD = (247, 238, 204), (255, 223, 0)
TRACK = {'inter': -0.055, 'serif': -0.01}  # letter spacing, as a share of the font size


@effect('film-grade', 'a warm, punchy film look that keeps you bright')
def fx_film_grade(c, e):
    img = c.img
    lum = (img @ np.float32([0.299, 0.587, 0.114]))[..., None]
    m = cv2.GaussianBlur(c.m, (0, 0), c.W / 90)[..., None]
    o = lum + (img - lum) * (float(e.o.get('sat', 0.95)) + 0.2 * m)  # richer colour, most of all on you
    o = np.power(np.clip(o * (1 + float(e.o.get('lift', 0.12)) * m), 0, 1), 0.92)
    o = o + (1 - lum) * np.float32([-0.02, 0.008, 0.03]) + lum * np.float32([0.045, 0.02, -0.035])  # teal shadows, warm highlights
    o = 0.012 + o * 0.98
    # contrast pivoted low, so shadows deepen while skin stays bright
    o = np.clip(o + (o - 0.32) * float(e.o.get('contrast', 0.22)) * np.clip(1.2 - o, 0, 1), 0, 1)
    c.img = o * (float(e.o.get('room', 0.88)) * (1 - m) + m)
    vignette(c, float(e.o.get('vignette', 0.3)))


def phrases(words, fixes, groups):
    """Line the hand-written groups up with the spoken words, so each word keeps its own timing."""
    toks = []
    for w in words:
        txt = re.sub(r"[^\w']", '', w['w'])
        if txt: toks.append({'t': fixes.get(txt.lower(), txt), 's': w['s'], 'e': w['e']})
    out, i = [], 0
    for g in groups:
        heart_ = '♥' in g; p = []
        for tok in re.findall(r'\*[^*]+\*|[^\s*♥]+', g):
            emph = tok.startswith('*')
            for wd in tok.strip('*').split():
                if i >= len(toks): break
                p.append(dict(toks[i], t=wd, emph=emph)); i += 1
        if p: p[-1]['heart'] = heart_; out.append(p)
    for j, p in enumerate(out):
        nxt = out[j + 1][0]['s'] if j + 1 < len(out) else 1e9
        p[0]['until'] = min(max(p[-1]['e'] + 1.0, p[0]['s'] + 2.2), nxt - 0.1)
    return out


def width(s, kind, px):
    return font(kind, px).getlength(s) + TRACK[kind] * px * max(0, len(s) - 1)


def layout(p, sans_px, serif_px, max_w):
    """Plain words in small tight cream sans (about 20 letters a line, evenly split); each run of key words on its own line in the big italic, nudged right."""
    runs = []
    for k, w in enumerate(p):
        if not runs or runs[-1]['emph'] != w['emph']: runs.append({'emph': w['emph'], 'ks': []})
        runs[-1]['ks'].append(k)
    lines = []
    for r in runs:  # split long plain runs into evenly sized lines, so no word is left alone
        n = len(' '.join(p[k]['t'] for k in r['ks']))
        rows = 1 if r['emph'] else -(-n // 20); target = n / rows; cur = []
        for k in r['ks']:
            if cur and len(lines) < 99 and len(' '.join(p[i]['t'] for i in cur)) + len(p[k]['t']) / 2 > target and rows > 1:
                lines.append({'emph': False, 'ks': cur}); cur = []; rows -= 1
            cur.append(k)
        lines.append({'emph': r['emph'], 'ks': cur})
    y = 0; out = []
    for j, ln in enumerate(lines):
        kind, px = ('serif', serif_px) if ln['emph'] else ('inter', sans_px)
        x = int(sans_px * 0.6) if ln['emph'] and j else 0
        full = ' '.join(p[k]['t'] for k in ln['ks']) + (' ♥' if p[ln['ks'][-1]].get('heart') else '')
        px = min(px, int(px * (max_w - x) / max(1, width(full, kind, px))))
        f = font(kind, px); a, d = f.getmetrics()
        if j: y -= int(px * (0.3 if ln['emph'] else 0.02))
        words, cx = [], x
        for k in ln['ks']:
            words.append((k, cx)); cx += width(p[k]['t'] + ' ', kind, px)
        out.append({'kind': kind, 'px': px, 'y': y, 'h': a + d, 'words': words, 'end': cx})
        y += int((a + d) * (0.8 if ln['emph'] else 0.92))
    return out, max(l['end'] for l in out), y


def draw_word(s, kind, px, col):
    f = font(kind, px); pad = int(px * 0.4); tr = TRACK[kind] * px
    im = Image.new('RGBA', (int(width(s, kind, px)) + 2 * pad, int(px * 1.5) + 2 * pad), (0, 0, 0, 0))
    def put(d, x, y, fill):
        for ch in s:
            d.text((x, y), ch, font=f, fill=fill); x += f.getlength(ch) + tr
    for blur, alpha, dy in ((0.18, 120, 4), (0.05, 110, 2)):  # a wide soft shadow plus a tight one, so it reads on light walls
        sh = Image.new('RGBA', im.size, (0, 0, 0, 0)); put(ImageDraw.Draw(sh), pad, pad + dy, (20, 12, 4, alpha))
        im = Image.alpha_composite(im, sh.filter(ImageFilter.GaussianBlur(px * blur)))
    put(ImageDraw.Draw(im), pad, pad, col + (255,))
    return im, pad


@effect('captions', 'editorial captions beside you: tight cream sans, key words in a big gold italic, fading in word by word')
def fx_captions(c, e):
    def build():
        fixes = {k.lower(): v for k, v in (kv.split('=', 1) for kv in e.o.get('fix', '').split('|') if '=' in kv)}
        return phrases(json.load(open(e.o['words'])), fixes, [g for g in e.o['groups'].split('|') if g.strip()])
    ps = cached(e, 'ps', build)
    t = c.t; sc = c.H / 1080 * float(e.o.get('size', 1.0))
    col, acc = rgb(e.o.get('color'), CREAM), rgb(e.o.get('accent'), GOLD)
    for j, p in enumerate(ps):
        if not (p[0]['s'] - 0.02 <= t < p[0]['until']): continue
        if ('pos', j) not in e.state:
            gap = c.fw * 1.05; left_room = c.fx - gap - c.W * 0.05; right_room = c.W - (c.fx + gap) - c.W * 0.05
            on_right = j % 2 == 1 and right_room > left_room * 0.6
            L, bw, bh = layout(p, int(60 * sc), int(132 * sc), right_room if on_right else left_room)
            x0 = c.fx + gap if on_right else c.fx - gap - bw
            e.state[('pos', j)] = (L, x0, c.fy - c.fw * 0.15 - bh / 2)
        L, x0, y0 = e.state[('pos', j)]
        out = clamp((p[0]['until'] - t) / 0.35)
        for ln in L:
            for k, wx in ln['words']:
                w = p[k]; kin = fx.ease_out((t - w['s'] + 0.04) / 0.3)  # each word fades up as it is said
                if kin <= 0: continue
                im, pad = cached(e, ('w', j, k), lambda: draw_word(w['t'], ln['kind'], ln['px'], acc if w['emph'] else col))
                comp(c, im, x0 + wx - pad, y0 + ln['y'] - pad + (1 - kin) * 10 * sc, alpha=kin * out, guard=True)
                if w.get('heart'):
                    hk = fx.ease_back((t - w['e']) / 0.3)
                    if hk > 0:
                        hs = ln['px'] * (0.45 if w['emph'] else 0.7)
                        hx = x0 + wx + width(w['t'], ln['kind'], ln['px']) + ln['px'] * 0.18
                        fx.place(c, cached(e, ('h', j), lambda: heart(hs * 2, (255, 255, 255))), hx + hs / 2, y0 + ln['y'] + ln['h'] * 0.55,
                                 scale=0.5 * hk, alpha=out)


if __name__ == '__main__':
    fx.main()
