# My Edit Style: a video editing skill for Claude Code

Gives any talking-head video my look:
- a warm, bright colour grade
- captions beside your face: small cream words with the key words in a big gold italic, fading in word by word as you speak, with little ♥s
- louder, clearer audio

## Install (once)
1. Install Claude Code if you don't have it: https://claude.com/claude-code
2. Unzip this folder and move it to:
   - Mac: `~/.claude/skills/my-edit-style`  (in Finder: Go → Go to Folder… → type `~/.claude/skills`, create it if missing)
   - Windows: `%USERPROFILE%\.claude\skills\my-edit-style`
   The folder must be named exactly `my-edit-style` and contain `SKILL.md` directly inside.
3. Restart Claude Code.

> Easiest: open Claude Code and say *"Install the skill in ~/Downloads/2026-10-28_my-edit-style-skill into ~/.claude/skills/my-edit-style"*. It will do it for you.

## Use it
1. Open Claude Code and drag your video into the chat.
2. Type `/my-edit-style`
3. The first run sets itself up (a few minutes: it installs ffmpeg/Python packages if needed). Then it edits your video and saves it in `Documents/my-edits/` named like `2026-10-28_what-your-video-is-about.mp4`.

Then just ask for tweaks in plain words: "make *this word* gold", "captions bigger", "face a bit brighter".

Watch the result before posting. Captions use your exact words, so check spellings.

Credits: built on the open-source effects engine by @vibha.in.progress (MIT, see LICENSE-effects). Fonts and models keep their own licences (in `fonts/` and `models/`).
