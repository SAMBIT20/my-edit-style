---
name: my-edit-style
description: Sambit's signature talking-head edit. A warm, punchy colour grade that keeps the face bright, plus editorial captions beside the face (small tight cream Inter, key words in a big gold #FFDF00 italic serif, fading in word by word, small white hearts) and loudness-boosted audio. Use when the user asks to edit a video "in my style", "same as before", "my edit style", or types /my-edit-style.
---

# My edit style

The user is not technical. Keep replies short, do the work yourself, never ask them to run commands.
All paths below are relative to this skill's folder (the folder this SKILL.md is in); use its absolute path in commands.
Finished videos go in `~/Documents/my-edits/`, with the plan and words file next to them.

**File names (the user insists on this):** `YYYY-MM-DD_<topic-slug>`, where the date is today and the slug is 3–5 lowercase hyphenated words saying what the video is *about* (from the transcript), never the camera's file name. E.g. `2026-10-28_finally-back-saas-journey.mp4`, `..._plan.json`, `..._words.json`. Below, `<name>` means this. If a file with that name exists, add `-v2`, `-v3`.

## The look (keep it consistent: don't change these unless the user asks)
- **Grade** (`film-grade`): warm, richer colour on the person, low-pivoted contrast (shadows deepen, skin stays bright), teal shadows / warm highlights, room slightly darker than the person, soft vignette. Defaults are the approved look. **The user disliked a stronger S-curve that darkened their face**: never push contrast up around skin tones.
- **Captions** (`captions`):
  - Plain words: Inter weight 520, tight tracking, lowercase as spoken, cream `#F7EECC`.
  - Key words: Instrument Serif Italic, big, gold `#FFDF00` (the user picked it; coral `#FF6F4F` was the runner-up), on their own line nudged right.
  - Layout: beside the face at eye level, alternating left/right, never over the face, with a soft dark shadow so it reads on light walls.
  - Timing: words fade up one by one as spoken. Each phrase stays at least 2.2 s and holds 1 s after the last word, then fades out.
  - The user said earlier versions were "too fast": keep phrases as full thoughts, never 1–2 word flashes.
- **Audio**: normalised to -14 LUFS stereo (their recordings are quiet).

## 1. Set up (first run only)
`bash scripts/setup.sh` → prints `READY`. `NEED_FFMPEG`: `brew install ffmpeg`. `NEED_PYTHON`: `brew install python@3.12`, rerun.

## 2. Transcribe
`.venv/bin/python scripts/transcribe.py <video> ~/Documents/my-edits/<name>_words.json`
Read the transcript. Fix obvious mishearings with the `fix` option (e.g. `sas=SaaS`).

## 3. Write the plan
Save as `~/Documents/my-edits/<name>_plan.json`. Copy the shape of `presets/example-plan.json`:
```json
{"effects": [
  {"fx": "film-grade", "start": 0, "end": 999},
  {"fx": "captions", "start": 0, "end": 999, "words": "<abs path to words.json>", "fix": "sas=SaaS",
   "groups": "Hey this is *Sambit*|and after a long break I am *finally back* ♥|..."}
]}
```
Writing `groups` (this is the craft. Do it by hand, not mechanically):
- Split the transcript into `|`-separated phrases **in spoken order, covering every word exactly once** (the words are matched to the transcript one by one by position, so the counts must line up).
- Each phrase is one natural thought, about 4–10 words. Merge any phrase that would be on screen under ~1.5 s with its neighbour.
- Wrap the 1–3 words that carry the meaning in `*stars*` (numbers, feelings, the payoff: `*500 views*`, `*disappointing*`, `*finally back*`). At most one starred run per phrase is best.
- End 3–4 warm or upbeat phrases with ` ♥` (not every phrase).
- Verify the alignment before rendering: `cd scripts && ../.venv/bin/python check_groups.py <plan>`. It must say every spoken word is placed with no MISMATCH. On-screen durations should mostly be ≥ 1.8 s.

## 4. Check, then render
1. Check frames (fast): `bash scripts/render.sh <plan> <video> /tmp/check.png --still 5,15,30`. Look at the PNGs yourself: text readable, not over the face, gold words clear on that background. A very bright yellow background can hide gold; in that case try `"accent": "FF6F4F"` and tell the user.
2. Render: `bash scripts/render.sh <plan> <video> ~/Documents/my-edits/<name>.mp4`
3. `open -a "QuickTime Player" <output>` (VS Code's preview plays AAC audio muted, so don't rely on it), tell them where it is, and ask them to watch it before posting.

## Options (only when asked)
`captions`: `color`, `accent` (hex), `size` (1.0 = default). `film-grade`: `sat` (0.95), `lift` (0.12, face brightness), `contrast` (0.22), `room` (0.88, background brightness), `vignette` (0.3).

Built on the open-source effects engine by @vibha.in.progress (MIT, see LICENSE-effects): face tracking via YuNet and the MediaPipe selfie segmenter, licences in `fonts/` and `models/`.
